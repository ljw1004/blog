//-----------------------------------------------------------------------------
//
// File:	Plugin3.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

static Pixel				palette[MAXRESONATORS];
static long					resonators;
#define	dB					48

static void initPalette()
{
	long		i, r = resonators;
	double		v;
	Pixel		*P = palette;

	for (i = 0; i < r; ++i, ++P) {
		v = sqrt(cos(PI/2*clamp(((i + (r/3)) % r - (r/2)) / (double)(r/3), -1, 1)));
		P->r = (unsigned char)(v * 255);
		v = sqrt(cos(PI/2*clamp(((i        ) % r - (r/2)) / (double)(r/3), -1, 1)));
		P->g = (unsigned char)(v * 255);
		v = sqrt(cos(PI/2*clamp(((i - (r/3)) % r - (r/2)) / (double)(r/3), -1, 1)));
		P->b = (unsigned char)(v * 255);
	}
}
static int Render()
{
	long		i, j, x, y;
	long		xmid, ymid;
	double		d, g = sqrt(2);
	long		v;
	Pixel		P;

	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 40) return 0;
	ticks = tickcount;

	P.r = 200; P.g = 170; P.b = 158; P.a = 255;
	Decay(P, 0, 0, info->buffer->xSize, info->buffer->ySize);

	xmid = info->buffer->xSize/2;
	ymid = info->buffer->ySize/2;
	for (j = 0; j < 2; ++j)
	for (i = 0; i < resonators; ++i) {
		d = 1 + 10 * log10(info->energy[j][i]) / dB;
		v = (long)(d * g * ymid); v = clamp(v, 0, ymid);
		x = j? xmid + 0 + i : xmid - 1 - i;
		for (y = ymid - v; y < ymid + v; ++y)
			info->buffer->rows[y][x] = palette[i];
	}
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(2)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "Resonatorz";
	if (pluginInfo)
	{
		pluginInfo->about = 0;
		pluginInfo->configure = 0;
	}
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		resonators = clamp(info->buffer->xSize / 12 * 6, 1, 120);
		initPalette();

		info->triggerMode = noTrigger;
		info->triggerForm = 0;
		info->resonatorMode = stereoResonators;
		info->resonatorForm = resonators;
		info->vuMeterMode = noVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->resize = 0;
		info->render = Render;
		info->idle = 0;
		info->wrap = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin3.cpp
//