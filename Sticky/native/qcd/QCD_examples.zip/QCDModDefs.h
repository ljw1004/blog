//-----------------------------------------------------------------------------
//
// File:	QCDModDefs.h
//
// About:	Module definitions file.  Miscellanious definitions used by different
//			module types.  This file is published with the plugin SDKs.
//
// Authors:	Written by Paul Quinn and Richard Carlson.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	Copyright (C) 2000 Richard Carlson for Quinnware
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#ifndef QCDMODINFO_H
#define QCDMODINFO_H

#include <windows.h>

#define PLUGIN_API extern "C" __declspec(dllexport)

// Current plugin version
#define PLUGIN_API_VERSION 201

//-----------------------------------------------------------------------------

typedef struct {
	char				*moduleString;
	char				*moduleExtensions;

} QCDModInfo;

//-----------------------------------------------------------------------------
// Services (ops) provided by the Player
//-----------------------------------------------------------------------------
typedef enum 
{									// below returns numeric info (InfoOpParm not used)

	opGetPlayerVersion = 0,			// high-order word = major version (eg 3.01 is 3), low-order word = minor (eg 3.01 = 1)
	opGetParentWnd = 1,				// handle to player window

	opGetNumTracks = 10,			// number of tracks in playlist
	opGetTrackIndex = 11,			// current track index in playlist (0 based)
	opGetNextTrackIndex = 12,		// get index of next track to play (0 based), param = index start index. -1 for after current
	opGetTrackNum = 13,				// get track number, param1 = index of track in playlist, -1 for current
	opGetTrackTime = 14,			// get track length in seconds, param1 = index of track in playlist, -1 for current
	opGetTime = 15,					// get time on player, param1 = 0 for time displayed, 1 for track time, 2 for playlist time
									//					   param2 = 0 for elapsed, 1 for remaining														   

	opGetOffline = 20,				// true if client is in Offline Mode
	opGetVisDetached = 21,			// true if vis is operating in external window


   									// below returns string info in buffer, param1 = size of buffer
   									// returns 1 on success, 0 on failure

	opGetTrackName = 100,			// get track name, param2 = index of track in playlist, -1 for current
	opGetArtistName = 101,			// get artist name, param2 = index of track in playlist, -1 for current
	opGetDiscName = 102,			// get disc name, param2 = index of track in playlist, -1 for current
	opGetTrackFile = 103,			// file name of track in playlist, param2 = index of track in playlist, -1 for current
	opGetSkinName = 104,			// get current skin name
	opGetPluginFolder = 105,		// get current plugin folder
	opGetPluginSettingsFile = 106,	// get settings file (plugins.ini) that plugin should save settings to


   									// below returns struct info in buffer
   									// returns 1 on success, 0 on failure

	opGetEQVals = 200,				// get current equalizer vals (buffer = *EQVals, param1 = size of EQVals)


									// below send information to player
									// returns 1 on success, 0 on failure

	opSetStatusMessage = 1000,		// display message in status area (buffer = msg buffer (null term), param1 = text flags)
	opSetMediaUrl = 1001,			// set music browser URL (buffer = url (null term))
	opSetAudioInfo = 1002,			// set the current music bitrate/khz (buffer = *AudioInfo, param1 = size of AudioInfo)

	opSetTrackAlbum = 1003,			// update current track ablum name (buffer = album (null term), param1 = (string ptr)current media name), param2 = MediaTypes
	opSetTrackTitle = 1004,			// update current track title (buffer = title (null term), param1 = (string ptr)current media name), param2 = MediaTypes
	opSetTrackArtist = 1005,		// update current track artist name (buffer = artist (null term), param1 = (string ptr)current media name), param2 = MediaTypes

	opSetPlaylist = 1006,			// add files to or reset playlist with new files (buffer = file list (null term), param1 = originating path (can be NULL), param2 = clear playlist flag


	opSafeWait = 10000

} PluginServiceOp;

//-----------------------------------------------------------------------------
// Info services api provided by the Player, called by Plugin.
//-----------------------------------------------------------------------------
typedef long (*PluginServiceFunc)(PluginServiceOp op, void *buffer, long param1, long param2);


//-----------------------------------------------------------------------------
typedef struct				// for Output Plugin Write callback
{
	void	*data;			// pointer to valid data
	UINT	bytelen;		// length of data pointed to by 'data' in bytes
	UINT	numsamples;		// number of samples represented by 'data'
	UINT	bps;			// bits per sample
	UINT	nch;			// number of channels
	UINT	srate;			// sample rate

	UINT	markerstart;	// Marker position at start of data
	UINT	markerend;		// Marker position at end of data
} WriteDataStruct;

//-----------------------------------------------------------------------------
typedef struct			// for GetTrackExtents Input Plugin callback
{
	UINT track;			// for CD's, set the track number. Otherwise set to 1.
	UINT start;			// for CD's or media that doesn't start at the beginning 
						// of the file, set to start position. Otherwise set to 0.
	UINT end;			// set to end position of media.
	UINT unitpersec;	// whatever units are being used for this media, how many
						// of them per second. 
						// (Note: ((end - start) / unitpersecond) = file length
	UINT bytesize;		// size of file in bytes (if applicable, otherwise 0).
} TrackExtents;

//-----------------------------------------------------------------------------
typedef struct			// for opSetAudioInfo service
{		
    long struct_size;	// sizeof(AudioInfo)
    long level;			// MPEG level (1 for MPEG1, 2 for MPEG2, 3 for MPEG2.5)
    long layer;			// and layer (1, 2 or 3)
    long bitrate;		// audio bitrate in bits per second
    long frequency;		// audio freq in Hz
    long mode;			// 0 for stereo, 1 for joint-stereo, 2 for dual-channel, 3 for mono
} AudioInfo;

//-----------------------------------------------------------------------------
// Equalizer Info
//-----------------------------------------------------------------------------
typedef struct			// for coming QCD version
{
	long struct_size;	// sizeof(EQInfo)
	long enabled;		
	long preamp;		// 0-100, 50 is +0, 0 is -10, 100 is +10
	long data[10];		// 0-100 each, 50 is +0, 0 is -10, 100 is +10
} EQInfo;

//-----------------------------------------------------------------------------
typedef enum			// for MediaInfo.mediaType
{ 
	UNKNOWN_MEDIA, CD_AUDIO_MEDIA, DIGITAL_FILE_MEDIA, DIGITAL_STREAM_MEDIA 
} MediaTypes;

//-----------------------------------------------------------------------------
#define MAX_TOC_LEN				2048
typedef struct
{
	// media descriptors
	CHAR		mediaFile[MAX_PATH];
	MediaTypes	mediaType;

	// cd audio media info
	CHAR		cd_mediaTOC[MAX_TOC_LEN];
	int			cd_numTracks;
	int			cd_hasAudio;

	// operation info
	int			op_canSeek;

	// not used
	int			reserved[4];

} MediaInfo;

//-----------------------------------------------------------------------------

// SystemMessage flags
#define TEXT_DEFAULT		0x0
#define TEXT_TOOLTIP		0x1
#define TEXT_URGENT			0x2
#define TEXT_HOLD			0x4

// Wave Marker flags
#define WAVE_VIS_DATA_ONLY	   -1

// Wave Sync flags
#define OUTPUT_OK_TO_VIS		23
#define OUTPUT_NOT_FOR_VIS		17

// pause flags
#define PAUSE_DISABLED			0
#define PAUSE_ENABLED			1



#endif //QCDMODINFO_H