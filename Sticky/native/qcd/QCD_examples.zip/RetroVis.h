//-----------------------------------------------------------------------------
//
// File:	RetroVis.cpp
//
// About:	Includes, functions, and definitions that are common to the 
//			plugins.
//
// Authors:	Written by Paul Quinn.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	Copyright (C) 2000 Richard Carlson for Quinnware
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------


#ifndef RETROVIS_H
#define RETROVIS_H

#include <cmath>
#define PLUGIN_API extern "C" __declspec(dllexport)

#include "QCDModVisuals.h"

// shared globals
#undef PI
#undef sgn
#undef abs
#undef max
#undef min
#undef clamp
const long double			PI = 3.1415926535897932384626433832795;
#define sgn(n)				((n)<0?-1:0<(n)?+1:0)
#define abs(n)				((n)<0?-(n):(n))
#define max(a,b)			((a)<(b)?(b):(a))
#define min(a,b)			((a)<(b)?(a):(b))
#define clamp(n,lo,hi)		((n)<(lo)?(lo):(hi)<(n)?(hi):(n))

extern PluginInfo*			info;
extern unsigned char		mul[256][256];

void InitMul();
void Decay(Pixel P, long x0, long y0, long x1, long y1);
void LineMC(long x0, long y0, long x1, long y1, long cmp, Pixel S);
void trace(void);
void PixelCompC(Pixel S, long x, long y);
void PixelC(long x, long y, Pixel S);
void LineC(long x0, long y0, long x1, long y1, Pixel S);



#endif