//-----------------------------------------------------------------------------
//
// File:	Plugin4.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

static VolveInfo			volve;
static int					mapReady;


static void Idle()
{
	int n = volve.tmp.xSize;

	// continue Map building after volve structure has been initialized
	while (!mapReady && n--)
		switch (info->opFunc(opMakeMap, &volve, 0, 0, 0, 0)) {
		case mapMaking:
			continue;
		case mapError:
			return;
		case mapDone:
			mapReady = !0;
		}	
}
static int Render()
{
	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 40) return 0;
	ticks = tickcount;
	if (mapReady)
		info->opFunc(opVolve, &volve, 0, 0, 0, 0);
	else {
		Pixel P; P.r = P.g = P.b = 225; P.a = 255;
		Decay(P, 0, 0, info->buffer->xSize, info->buffer->ySize);
	}
	trace();
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}
static void Wrap()
{
	info->opFunc(opFreeMap, &volve, 0, 0, 0, 0);
}
static void MapFunc(double *xcoord, double *ycoord)
{
	register double x = *xcoord;
	register double y = *ycoord;
	double			xorg = info->buffer->xSize / 2.;
	double			yorg = info->buffer->ySize / 2.;
	double			xsub = floor(x) + .5;
	double			ysub = floor(y) + .5;
	double			r, t;

	x -= xsub;
	y -= ysub;
	x *= 1.25;
	y *= 1.25;
	x += xsub;
	y += ysub;

	x -= xorg;
	y -= yorg;
	r = sqrt(x * x + y * y);
	t = atan2(y, x);
	r *= .75;
	t += sgn(x) * sgn(y) * PI / 36;
	x = r * cos(t);
	y = r * sin(t);
	x += xorg;
	y += yorg;

	*xcoord = x;
	*ycoord = y;
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(3)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "Wave Zoomer";
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		volve.dst = info->buffer;
		volve.alpha = 255;
		volve.decay = 240;
		volve.res = 2;
		volve.mapFunc = MapFunc;
		volve.map = 0;
		volve.mapSize = 0;
		volve.mapState = 0;
		// first call to opMakeMap sets VolveInfo buffer size and initializes build
		if (!info->opFunc(opMakeMap, &volve, 0, 0, info->buffer->xSize, info->buffer->ySize))
			return 0;
		mapReady = 0;

		info->triggerMode = monoTrigger;
		info->triggerForm = 0;
		info->resonatorMode = noResonators;
		info->resonatorForm = 0;
		info->vuMeterMode = noVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = Idle;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin4.cpp
//