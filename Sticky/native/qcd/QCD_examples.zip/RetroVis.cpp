//-----------------------------------------------------------------------------
//
// File:	RetroVis.cpp
//
// About:	See RetrovVis.h
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------


#include "RetroVis.h"

// common globals
PluginInfo*			info;
unsigned char		mul[256][256];

// common utils

void InitMul()
{
	unsigned long i, j;

	for (i = 0; i < 256; ++i)
		for (j = 0; j < 256; ++j)
			mul[i][j] = (unsigned char)(i * j / 255);
}

void Decay(Pixel P, long x0, long y0, long x1, long y1)
{
	register long x, y;
	register Pixel *D;

	for (y = y0; y < y1; ++y) {
		D = info->buffer->rows[y];
		for (x = x0; x < x1; ++x) {
			D[x].b = mul[P.b][D[x].b];
			D[x].g = mul[P.g][D[x].g];
			D[x].r = mul[P.r][D[x].r];
			D[x].a = mul[P.a][D[x].a];
		}
	}
}

void LineMC(long x0, long y0, long x1, long y1, long cmp, Pixel S)
{
	register long n, x, y, dx, dy;
	register Pixel *D;

	x = x0; dx = x1 - x0;
	y = y0; dy = y1 - y0;
	n = max(abs(dx), abs(dy));
	D = info->buffer->rows[y], D[x].v[cmp] = S.v[cmp];
	if (n) {
		x <<= 16; x += 1 << 15; dx <<= 16; dx /= n;
		y <<= 16; y += 1 << 15; dy <<= 16; dy /= n;
		while (n--) {
			x += dx;
			y += dy;
			D = info->buffer->rows[y >> 16], D[x >> 16].v[cmp] = S.v[cmp];
		}
	}
}

void trace(void)
{
	long				f, i, j, k[3];
	long				w = info->buffer->xSize;
	long				h = info->buffer->ySize;
	long				l;
	register short		*s = info->sound;
	static long			phase;
	static Pixel		lo = { 0xcc, 0xcc, 0xcc, 0xcc };
	static Pixel		hi = { 0xff, 0xff, 0xff, 0xff };

	w = clamp(w, 0, SAMPLES);
	f = max(1, SAMPLES / w);
	s += phase * 2; phase = (phase + 1) % f;
	for (i = 0; i < w; ++i, s += f * 2) {

		l = (long)s[0];
		l *= h / 2 - 1;
		l >>= 15;
		j = l + h / 2;
		LineMC(i, h / 2, i, j, roff, hi);
		if (i) LineMC(i - 1, k[0], i, j, roff, hi);
		k[0] = j;

		l = (long)s[1];
		l *= h / 2 - 1;
		l >>= 15;
		j = l + h / 2;
		LineMC(i, h / 2, i, j, boff, hi);
		if (i) LineMC(i - 1, k[1], i, j, boff, hi);
		k[1] = j;

		l = (long)s[0] + (long)s[1];
		l *= h / 2 - 1;
		l >>= 16;
		j = l + h / 2;
		LineMC(i, h / 2, i, j, goff, lo);
		if (i) LineMC(i - 1, k[2], i, j, goff, hi);
		k[2] = j;
	}
}

void PixelCompC(Pixel S, long x, long y)
{
	register Pixel *D;

	if (0 <= x && x < info->buffer->xSize
	&&	0 <= y && y < info->buffer->ySize) {
		D = info->buffer->rows[y];
		D[x].r = mul[S.a][S.r] + mul[255-S.a][D[x].r];
		D[x].g = mul[S.a][S.g] + mul[255-S.a][D[x].g];
		D[x].b = mul[S.a][S.b] + mul[255-S.a][D[x].b];
	}
}

void PixelC(long x, long y, Pixel S)
{
	register Pixel *D;

	if (info->buffer->x0 <= x && x < info->buffer->x1
	&&	info->buffer->y0 <= y && y < info->buffer->y1)
		D = info->buffer->rows[y], D[x].b = S.b, D[x].g = S.g, D[x].r = S.r;
}

void LineC(long x0, long y0, long x1, long y1, Pixel S)
{
	register long n, x, y, dx, dy;

	x = x0; dx = x1 - x0;
	y = y0; dy = y1 - y0;
	n = max(abs(dx), abs(dy));
	PixelC(x, y, S);
	if (n) {
		x <<= 16; x += 1 << 15; dx <<= 16; dx /= n;
		y <<= 16; y += 1 << 15; dy <<= 16; dy /= n;
		while (n--) {
			x += dx;
			y += dy;
			PixelC(x >> 16, y >> 16, S);
		}
	}
}

