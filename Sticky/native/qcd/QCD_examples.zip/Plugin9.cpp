//-----------------------------------------------------------------------------
//
// File:	Plugin9.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

static VolveInfo			volve;
static int					mapReady;
static long					resonators;
#define	dB					48

static Pixel				palette[MAXRESONATORS];


static inline void PixelS(long x, long y, Pixel S)
{
	register Pixel *D;

	if (info->buffer->x0 <= x && x < info->buffer->x1
	&&	info->buffer->y0 <= y && y < info->buffer->y1)
		D = info->buffer->rows[y], D[x].b = max(S.b, D[x].b), D[x].g = max(S.g, D[x].g), D[x].r = max(S.r, D[x].r);
}
static inline void LineS(long x0, long y0, long x1, long y1, Pixel S)
{
	register long n, x, y, dx, dy;

	x = x0; dx = x1 - x0;
	y = y0; dy = y1 - y0;
	n = max(abs(dx), abs(dy));
	PixelS(x, y, S);
	if (n) {
		x <<= 16; x += 1 << 15; dx <<= 16; dx /= n;
		y <<= 16; y += 1 << 15; dy <<= 16; dy /= n;
		while (n--) {
			x += dx;
			y += dy;
			PixelS(x >> 16, y >> 16, S);
		}
	}
}
static void initPalette()
{
	long		i, r = resonators;
	Pixel		*P = palette;

	for (i = 0; i < r; ++i, ++P) {
		switch (i % 12) {
		case  0:	P->r = 255; P->g = 127; P->b = 127; break;
		case  1:	P->r = 255; P->g = 191; P->b = 127; break;
		case  2:	P->r = 255; P->g = 255; P->b = 127; break;
		case  3:	P->r = 191; P->g = 255; P->b = 127; break;
		case  4:	P->r = 127; P->g = 255; P->b = 127; break;
		case  5:	P->r = 127; P->g = 255; P->b = 191; break;
		case  6:	P->r = 127; P->g = 255; P->b = 255; break;
		case  7:	P->r = 127; P->g = 191; P->b = 255; break;
		case  8:	P->r = 127; P->g = 127; P->b = 255; break;
		case  9:	P->r = 191; P->g = 127; P->b = 255; break;
		case 10:	P->r = 255; P->g = 127; P->b = 255; break;
		case 11:	P->r = 255; P->g = 127; P->b = 191; break;
		}
	}
}
static void Idle()
{
	int n = volve.tmp.xSize;

	// continue Map building after volve structure has been initialized
	while (!mapReady && n--) {
		switch (info->opFunc(opMakeMap, &volve, 0, 0, 0, 0)) {
		case mapMaking:
			continue;
		case mapError:
			return;
		case mapDone:
			mapReady = !0;
		}
	}
}
static int Render()
{
	long		i, j, k;
	double		x0, y0, x1, y1;
	long		xmid, ymid;
	double		d, g = sqrt(2), radius, r, t, a, alpha;
	long		phase;
	Pixel		P;

	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 20) return 0;
	ticks = tickcount;

	if (mapReady)
		info->opFunc(opVolve, &volve, 0, 0, 0, 0);
	else {
		P.r = 200; P.g = 170; P.b = 158; P.a = 255;
		Decay(P, 0, 0, info->buffer->xSize, info->buffer->ySize);
	}
	xmid = info->buffer->xSize/2;
	ymid = info->buffer->ySize/2;
	radius = min(xmid, ymid);
	for (j = 0; j < 2; ++j) {
		phase = (long)(info->vumeter[j] / sqrt(2) * resonators);
		phase = max(phase, 0);
		for (i = 0; i < resonators; ++i) {
			a = (i + 1) / (double)resonators;
			d = 1 + 10 * log10(info->energy[j][resonators-1-i]) / dB;
			alpha = d * g; alpha = clamp(alpha, 0, 1);
			P.a = (unsigned char)(255 * (alpha / 2 + .5));
			k = (i + phase) % resonators;
			P.r = mul[P.a][palette[k].r];
			P.g = mul[P.a][palette[k].g];
			P.b = mul[P.a][palette[k].b];
			r = a * radius;
			t = (a * resonators + phase / (double)resonators) * PI / 6;
			t -= alpha * PI/12;
			x0 = r * sin(j? +t : -t);
			y0 = r * cos(t);
			t += alpha * PI/6;
			x1 = r * sin(j? +t : -t);
			y1 = r * cos(t);
			LineS((long)(xmid + x0 + .5), (long)(ymid + y0 + .5),
				  (long)(xmid + x1 + .5), (long)(ymid + y1 + .5), P);
		}
	}
	++phase; phase %= resonators;
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}

static void Wrap()
{
	info->opFunc(opFreeMap, &volve, 0, 0, 0, 0);
}
static void MapFunc(double *xcoord, double *ycoord)
{
	register double x = *xcoord;
	register double y = *ycoord;
	double			xorg = info->buffer->xSize / 2.;
	double			yorg = info->buffer->ySize / 2.;
	double			xsub = floor(x) + .5;
	double			ysub = floor(y) + .5;
	double			r;

	r = min(xorg, yorg);
	r = r * r;

	x -= xsub;
	y -= ysub;
	x *= 2.5;
	y *= 2.5;
	x += xsub;
	y += ysub;

	x -= xorg;
	y -= yorg;
	if (x * x + y * y > r) {
		*xcoord = *ycoord = -1;
		return;
	}
	x *= .98;
	y *= .98;
	x += xorg;
	y += yorg;

	*xcoord = x;
	*ycoord = y;
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(8)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "Rez Wheel";
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		resonators = 120;
		initPalette();

		volve.dst = info->buffer;
		volve.alpha = 225;
		volve.decay = 240;
		volve.res = 3;
		volve.mapFunc = MapFunc;
		volve.map = 0;
		volve.mapSize = 0;
		volve.mapState = 0;
		// first call to opMakeMap sets VolveInfo buffer size and initializes build
		if (!info->opFunc(opMakeMap, &volve, 0, 0, info->buffer->xSize, info->buffer->ySize))
			return 0;
		mapReady = 0;

		info->triggerMode = noTrigger;
		info->triggerForm = 0;
		info->resonatorMode = stereoResonators;
		info->resonatorForm = resonators;
		info->vuMeterMode = stereoVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = Idle;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin9.cpp
//