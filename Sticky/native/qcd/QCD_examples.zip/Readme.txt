===============================================================================

	QCD Retro Vis Pack Readme.txt 

	QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
	prior to  version 3.0.

	Copyright (C) 2001 David Levine, Richard Carlson for Quinnware

	This code is free.  If you redistribute it in any form, leave this notice 
	here.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

===============================================================================

	This code is provided to help illustrate how to write QCD Player plugins.
	These plugins were written some time ago, but they still work and show
	how to interface with the current APIs.

	The project is ready to go and may be immediatly compiled to create a
	dynamic link library plugin.  If the created file is then copied to your 
	player's plugin directory, it will show up in the player's visual plugin 
	list.

	Please send your questions and comments via email to "QCD@quinnware.com"

	We look forward to seeing what you create.

	--QCD Team
