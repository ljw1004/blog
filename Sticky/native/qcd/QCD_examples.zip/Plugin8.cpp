//-----------------------------------------------------------------------------
//
// File:	Plugin8.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

#define shapeXSize			32
#define shapeYSize			32
#define shapeRes			4

static Raster				shape;


static inline void RGBFill(Raster *dst, Pixel P)
{
	register long		x, y;
	register Pixel		*D;

	for (y = dst->y0; y < dst->y1; ++y) {
		D = dst->rows[y];
		for (x = dst->x0; x < dst->x1; ++x) {
			D[x].b = P.b;
			D[x].g = P.g;
			D[x].r = P.r;
		}
	}
}
static inline void Clear(Raster *dst)
{
	register long		x, y;

	for (y = dst->y0; y < dst->y1; ++y)
		for (x = dst->x0; x < dst->x1; ++x)
			dst->rows[y][x].l = 0;
}
static void Ellipse2Alpha(Raster *dst, long res)
{
	long		i, j, x, y, supersample;
	long		s0[2], s1[2], s2[2], s3[2], s4[2];
	long		xm[2], ym[2], xn[2], yn[2];
	long		k, z, scale, samples;
	double		dx, dy, ex, ey;
	double		v[4][2], vo[2], vx[2], vy[2];
	Pixel		*D;
	const long	radix = 30;

	v[0][0] = -1; v[0][1] = -1;
	v[1][0] = +1; v[1][1] = -1;
	v[2][0] = -1; v[2][1] = +1;

	scale = res * 2;
	samples = 1L << scale;
	supersample = 1L << res;

	dx = 1. / (dst->x1 - dst->x0); ex = dx / supersample;
	dy = 1. / (dst->y1 - dst->y0); ey = dy / supersample;
	for (z = 0; z < 2; ++z) {
		vo[z] = (v[0][z]) * (double)(1L << radix);
		vx[z] = (v[1][z] - v[0][z]) * (double)(1L << radix);
		vy[z] = (v[2][z] - v[0][z]) * (double)(1L << radix);
		s0[z] = (long)(vo[z] + (vx[z] * ex + vy[z] * ey) / 2);
		xn[z] = (long)(vx[z] * dx);
		yn[z] = (long)(vy[z] * dy);
		xm[z] = (long)(vx[z] * ex);
		ym[z] = (long)(vy[z] * ey);
	}
	for (y = dst->y0; y < dst->y1; ++y) {
		s1[0] = s0[0]; s0[0] += yn[0];
		s1[1] = s0[1]; s0[1] += yn[1];
		D = dst->rows[y];
		for (x = dst->x0; x < dst->x1; ++x) {
			s2[0] = s1[0]; s1[0] += xn[0];
			s2[1] = s1[1]; s1[1] += xn[1];
			k = 0;
			for (j = 0; j < supersample; ++j) {
				s3[0] = s2[0]; s2[0] += ym[0];
				s3[1] = s2[1]; s2[1] += ym[1];
				for (i = 0; i < supersample; ++i) {
					s4[0] = s3[0] >> radix / 2; s3[0] += xm[0];
					s4[1] = s3[1] >> radix / 2; s3[1] += xm[1];
					if (s4[0] * s4[0] + s4[1] * s4[1] <= 1L << radix)
						++k;
				}
			}
			D[x].a = (unsigned char)(k * 255 >> scale);
		}
	}
}

#define	dB		48
static int Render()
{
	long			i, j, k, x, y;
	double			pan, zoom, vu, d, a, g = sqrt(2);
	static			BlitInfo B;
	Pixel			P;
	static Pixel	C;

	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 20) return 0;
	ticks = tickcount;

	P.a = 255; P.r = 0; P.g = 0; P.b = 0;
	for (y = 0; y < info->buffer->ySize; ++y)
		for (x = 0; x < info->buffer->xSize; ++x)
			info->buffer->rows[y][x] = P;

	d = 1 + 10 * log10(info->energy[0][0]) / dB; a = d * g; a = clamp(a, 0, 1);
	C.r = (unsigned char)((128 + 64 * a + C.r) / 2);
	d = 1 + 10 * log10(info->energy[0][1]) / dB; a = d * g; a = clamp(a, 0, 1);
	C.g = (unsigned char)((128 + 64 * a + C.g) / 2);
	d = 1 + 10 * log10(info->energy[0][2]) / dB; a = d * g; a = clamp(a, 0, 1);
	C.b = (unsigned char)((128 + 64 * a + C.b) / 2);

	vu = (info->vumeter[0] + info->vumeter[1]);
	zoom = .5 + vu / 4;
	if (vu) for (j = 0; j < 2; ++j) {
		i = j ^ (info->vumeter[0] > info->vumeter[1]);
		k = i? +1 : -1;

		pan = 2 * (info->vumeter[i] / vu - .5);

		P.l = -1;
		RGBFill(&shape, P);
 
		B.dst = *info->buffer;
		B.src = shape;
		B.res = 2;
		B.scalex = zoom * info->buffer->xSize / (2 * shapeXSize);
		B.scaley = zoom * info->buffer->ySize / (3 * shapeYSize);
		B.shearx = B.sheary = 0;
		B.offsetx = k * zoom * info->buffer->xSize / 3;
		B.offsety = 0;
		B.rotate = 0;
		B.alpha = (long)clamp(vu * 255, 0, 255);
		B.src.x0 = 0; B.src.x1 = shapeXSize;
		B.src.y0 = 0; B.src.y1 = shapeYSize;
		B.dst.x0 = 0; B.dst.x1 = info->buffer->xSize;
		B.dst.y0 = 0; B.dst.y1 = info->buffer->ySize;
		B.src.alphaEnable = !0;
		B.dst.alphaEnable = 0;
		info->opFunc(opComposite, (char *)&B, 0, 0, 0, 0);

		P.l = 0;
		RGBFill(&shape, P);
 
		B.scalex = zoom * info->buffer->xSize / (4 * shapeXSize);
		B.scaley = zoom * info->buffer->xSize / (4 * shapeYSize);
		B.shearx = B.sheary = 0;
		B.offsetx = k * zoom * (info->buffer->xSize * (1 + pan / 2)) / 3;
		B.offsety = 0;
		B.rotate = 0;
		B.alpha = 255;
		B.src.x0 = 0; B.src.x1 = shapeXSize;
		B.src.y0 = 0; B.src.y1 = shapeYSize;
		B.dst.x0 = 0; B.dst.x1 = info->buffer->xSize;
		B.dst.y0 = 0; B.dst.y1 = info->buffer->ySize;
		B.src.alphaEnable = !0;
		B.dst.alphaEnable = 0;
		info->opFunc(opComposite, (char *)&B, 0, 0, 0, 0);

		RGBFill(&shape, C);
 
		B.scalex = zoom * info->buffer->xSize / (8 * shapeXSize);
		B.scaley = zoom * info->buffer->xSize / (8 * shapeYSize);
		B.shearx = B.sheary = 0;
		B.offsetx = k * zoom * (info->buffer->xSize * (1 + 9 * pan / 16)) / 3;
		B.offsety = 0;
		B.rotate = 0;
		B.alpha = (long)clamp(vu * 255, 0, 255);
		B.src.x0 = 0; B.src.x1 = shapeXSize;
		B.src.y0 = 0; B.src.y1 = shapeYSize;
		B.dst.x0 = 0; B.dst.x1 = info->buffer->xSize;
		B.dst.y0 = 0; B.dst.y1 = info->buffer->ySize;
		B.src.alphaEnable = !0;
		B.dst.alphaEnable = 0;
		info->opFunc(opComposite, (char *)&B, 0, 0, 0, 0);
	}
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}
static void Wrap()
{
	info->opFunc(opFreeRaster, &shape, 0, 0, 0, 0);
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(7)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "I Meters";
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		if (!info->opFunc(opMakeRaster, &shape, 0, 0, shapeXSize, shapeYSize))
			return 0;
		Clear(&shape);
		Ellipse2Alpha(&shape, shapeRes);
		shape.alphaEnable = !0;

		info->triggerMode = noTrigger;
		info->triggerForm = 0;
		info->resonatorMode = monoResonators;
		info->resonatorForm = 3;
		info->vuMeterMode = stereoVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = 0;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin8.cpp
//
