//-----------------------------------------------------------------------------
//
// File:	Plugin6.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

static VolveInfo			volve;
static int					mapReady;
static Pixel				palette[MAXRESONATORS];
static long					resonators;
#define	dB					48

static void initPalette()
{
	long		i, r = resonators;
	double		v, p = 1 / 4.;
	Pixel		*P = palette;

	for (i = 0; i < r; ++i, ++P) {
		v = pow((double)cos(PI/2*clamp(((i + (r/3)) % r - (r/2)) / (double)(r/3), -1, 1)), p);
		P->r = (unsigned char)(v * 255);
		v = pow((double)cos(PI/2*clamp(((i        ) % r - (r/2)) / (double)(r/3), -1, 1)), p);
		P->g = (unsigned char)(v * 255);
		v = pow((double)cos(PI/2*clamp(((i - (r/3)) % r - (r/2)) / (double)(r/3), -1, 1)), p);
		P->b = (unsigned char)(v * 255);
	}
}
static void Idle()
{
	int n = volve.tmp.xSize;

	// continue Map building after volve structure has been initialized
	while (!mapReady && n--)
		switch (info->opFunc(opMakeMap, &volve, 0, 0, 0, 0)) {
		case mapMaking:
			continue;
		case mapError:
			return;
		case mapDone:
			mapReady = !0;
		}	
}
static int Render()
{
	long		i, j;
	double		x0, y0, x1, y1;
	long		xmid, ymid;
	double		d, g = sqrt(2), radius, r, t;
	static long	phase;
	Pixel		P;

	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 30) return 0;
	ticks = tickcount;

	if (mapReady)
		info->opFunc(opVolve, &volve, 0, 0, 0, 0);
	else {
		P.r = 200; P.g = 170; P.b = 158; P.a = 255;
		Decay(P, 0, 0, info->buffer->xSize, info->buffer->ySize);
	}

	xmid = info->buffer->xSize/2;
	ymid = info->buffer->ySize/2;
	radius = sqrt(xmid * xmid + ymid * ymid);
	for (j = 0; j < 2; ++j)
	for (i = 0; i < resonators; ++i) {
		d = 1 + 10 * log10(info->energy[j][i]) / dB;
		r = d * g * radius; r = clamp(r, 0, radius);
		t = (i * 4 + phase) * PI / (4 * resonators);
		x0 = r * sin(j? +t : -t);
		y0 = r * cos(t);
		x1 = x0 / 2;
		y1 = y0 / 2;
		LineC(	(long)(xmid + x0 + .5), (long)(ymid + y0 + .5),
				(long)(xmid + x1 + .5), (long)(ymid + y1 + .5), 
				palette[i]);
	}
	++phase; phase &= 3;
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}

static void Wrap()
{
	info->opFunc(opFreeMap, &volve, 0, 0, 0, 0);
}
static void MapFunc(double *xcoord, double *ycoord)
{
	register double x = *xcoord;
	register double y = *ycoord;
	double			xorg = info->buffer->xSize / 2.;
	double			yorg = info->buffer->ySize / 2.;
	double			xsub = floor(x) + .5;
	double			ysub = floor(y) + .5;
	double			r, t;

	x -= xsub;
	y -= ysub;
	x *= 1.5;
	y *= 1.5;
	x += xsub;
	y += ysub;

	x -= xorg;
	y -= yorg;
	r = sqrt(x * x + y * y);
	t = atan2(y, x);
	r *= .95;
	t += sgn(x) * sin(15 * PI * r / sqrt(xorg * xorg + yorg * yorg)) * PI / 60;
	x = r * cos(t);
	y = r * sin(t);
	x += xorg;
	y += yorg;

	*xcoord = x;
	*ycoord = y;
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(5)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "Rez Burst";
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		resonators = 30;
		initPalette();

		volve.dst = info->buffer;
		volve.alpha = 225;
		volve.decay = 240;
		volve.res = 2;
		volve.mapFunc = MapFunc;
		volve.map = 0;
		volve.mapSize = 0;
		volve.mapState = 0;
		// first call to opMakeMap sets VolveInfo buffer size and initializes build
		if (!info->opFunc(opMakeMap, &volve, 0, 0, info->buffer->xSize, info->buffer->ySize))
			return 0;
		mapReady = 0;

		info->triggerMode = noTrigger;
		info->triggerForm = 0;
		info->resonatorMode = stereoResonators;
		info->resonatorForm = resonators;
		info->vuMeterMode = noVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = Idle;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin6.cpp
//