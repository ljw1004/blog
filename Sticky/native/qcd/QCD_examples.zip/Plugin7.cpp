//-----------------------------------------------------------------------------
//
// File:	Plugin7.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

static inline void RGBRect(Raster *dst, long x0, long y0, long x1, long y1, Pixel P)
{
	register long		x, y;
	register Pixel		*D;

	for (y = y0; y < y1; ++y) if (0 <= y && y < dst->ySize) {
		D = dst->rows[y];
		for (x = x0; x < x1; ++x) if (0 <= x && x < dst->xSize) {
			D[x].b = P.b;
			D[x].g = P.g;
			D[x].r = P.r;
		}
	}
}
static inline void RGBFill(Raster *dst, Pixel P)
{
	RGBRect(dst, 0, 0, dst->xSize, dst->ySize, P);
}

static void trace(void)
{
	long				f, i, j, k[3];
	long				w = info->buffer->xSize;
	long				h = info->buffer->ySize;
	long				l;
	register short		*s = info->sound;
	static long			phase;
	Pixel				P;

	w = clamp(w, 0, SAMPLES);
	f = max(1, SAMPLES / w);
	s += phase * 2; phase = (phase + 1) % f;

	P.r = 17; P.g = 51; P.b = 17; P.a = 255;
	j = (long)(info->ppmeter[0] * h / 4);
	RGBRect(info->buffer, 0, 1 * h / 4 - j, w, 1 * h / 4 + j, P);
	j = (long)(info->ppmeter[1] * h / 4);
	RGBRect(info->buffer, 0, 3 * h / 4 - j, w, 3 * h / 4 + j, P);

	for (i = 0; i < w; ++i, s += f * 2) {
		P.r = 255; P.g = 95; P.b = 255; P.a = 255;

		l = (long)s[0];
		l *= h / 4 - 1;
		l >>= 15;
		j = l + 1 * h / 4;
		if (i) LineMC(i - 1, k[0], i, j, roff, P);
		k[0] = j;

		l = (long)s[1];
		l *= h / 4 - 1;
		l >>= 15;
		j = l + 3 * h / 4;
		if (i) LineMC(i - 1, k[1], i, j, boff, P);
		k[1] = j;

	}
}

static int Render()
{
	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 40) return 0;
	ticks = tickcount;

	{
		Pixel P; P.r = 0; P.g = 0; P.b = 0; P.a = 255;
		RGBFill(info->buffer, P);
	}
	trace();
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}
static void Wrap()
{
}
PLUGIN_API int VISUALDLL_ENTRY_POINT(6)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "Waves & Peak Meters";
	if (fullinit && pluginInfo) {
		info = pluginInfo;

		info->triggerMode = monoTrigger;
		info->triggerForm = 0;
		info->resonatorMode = noResonators;
		info->resonatorForm = 0;
		info->vuMeterMode = noVUMeter;
		info->ppMeterMode = stereoPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = 0;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin7.cpp
//