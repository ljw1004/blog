//-----------------------------------------------------------------------------
//
// File:	Plugin5.cpp
//
// About:	Visual plugin written for the QCD Player.
//
// Authors:	Written by David Levine.
//
// Copyright:
//
//  QCD Retro Vis Pack 
//
//  QCD Retro Vis Pack is a collection of all the visuals from versions of QCD
//  prior to  version 3.0.
//
//	This code is free.  If you redistribute it in any form, leave this notice 
//	here.
//
//	This program is distributed in the hope that it will be useful,
//	but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//
//-----------------------------------------------------------------------------

#include "RetroVis.h"

#define vuXSize				115
#define vuYSize				60
#define vuName				"vumeter"

static Raster				vuRaster[2], *buffer;
static RsrcInfo				rsrcInfo;

static void showVUMeter(long i)
{
	double			rho, theta;
	long			d, l, n, x, y, dx, dy;
	char			m;
	const double	range = 1.2277;	// +4 dBu
	Pixel			S;

	S.r = 255; S.g = 0; S.b = 0;

	rsrcInfo.info = info;
	rsrcInfo.name = vuName;
	info->opFunc(opBlitFromPict, &rsrcInfo, 0, 0, vuXSize, vuYSize);

	x = vuXSize / 2; 
	y = vuYSize / 2 + vuYSize;
	rho = 4 * vuYSize / 3;
	theta = (PI - range) / 2 + range * clamp(info->vumeter[i], 0, 1);
	dx = -(long)(rho * cos(theta));
	dy = -(long)(rho * sin(theta));

	S.a = 255;
	PixelCompC(S, x, y);
	if (abs(dx) > abs(dy)) {
		l = n = abs(dx); m = -(dy >= 0); d = m + m + 1;
		x <<= 16; x += 1 << 15; dx <<= 16; dx /= n;
		y <<= 16; y += 1 << 15; dy <<= 16; dy /= n;
		do {
			S.a = 255;
			PixelCompC(S, (x >> 16), (y >> 16));
			S.a = ( m)^(char)(y >> 8); if (n == 0 || n == l) S.a >>= 1;
			PixelCompC(S, (x >> 16), (y >> 16) + d);
			S.a = (~m)^(char)(y >> 8); if (n == 0 || n == l) S.a >>= 1;
			PixelCompC(S, (x >> 16), (y >> 16) - d);
			x += dx;
			y += dy;
		} while (n--);
	} else {
		l = n = abs(dy); m = -(dx >= 0); d = m + m + 1;
		x <<= 16; x += 1 << 15; dx <<= 16; dx /= n;
		y <<= 16; y += 1 << 15; dy <<= 16; dy /= n;
		do {
			S.a = 255;
			PixelCompC(S, (x >> 16), (y >> 16));
			S.a = ( m)^(char)(x >> 8); if (n == 0 || n == l) S.a >>= 1;
			PixelCompC(S, (x >> 16) + d, (y >> 16));
			S.a = (~m)^(char)(x >> 8); if (n == 0 || n == l) S.a >>= 1;
			PixelCompC(S, (x >> 16) - d, (y >> 16));
			x += dx;
			y += dy;
		} while (n--);
	}
}

static int Render()
{
	long		i, j, k, x, y;
	static		BlitInfo B;
	Pixel		P;

	unsigned long tickcount = info->opFunc(opGetMilliseconds, 0, 0, 0, 0, 0);
	static unsigned long ticks;

	if (tickcount - ticks < 20) return 0;
	ticks = tickcount;

	P.a = 255; P.r = 0; P.g = 0; P.b = 0;
	for (y = 0; y < info->buffer->ySize; ++y)
		for (x = 0; x < info->buffer->xSize; ++x)
			info->buffer->rows[y][x] = P;

	for (j = 0; j < 2; ++j) {
		i = j ^ (info->vumeter[0] > info->vumeter[1]);
		k = i? +1 : -1;
		info->buffer = &vuRaster[i];
		showVUMeter(i);
		info->buffer = buffer;
		B.dst = *buffer;
		B.src = vuRaster[i];
		B.res = 1;
		B.scalex = B.scaley = (info->buffer->xSize - 4) / 2.0 / vuXSize;
		B.shearx = B.sheary = 0;
		B.offsetx = k * (info->buffer->xSize - 2) / 4.0;
		B.rotate = 0;
		B.alpha = 255;
		B.src.x0 = 0; B.src.x1 = vuXSize;
		B.src.y0 = 0; B.src.y1 = vuYSize;
		B.dst.x0 = 0; B.dst.x1 = info->buffer->xSize;
		B.dst.y0 = 0; B.dst.y1 = info->buffer->ySize;
		B.src.alphaEnable = 0;
		B.dst.alphaEnable = 0;
		info->opFunc(opComposite, (char *)&B, 0, 0, 0, 0);
	}
	info->buffer->x0 = 0; info->buffer->x1 = info->buffer->xSize;
	info->buffer->y0 = 0; info->buffer->y1 = info->buffer->ySize;

	return !0;
}

static void Wrap()
{
	for (int i = 1; i >= 0; --i)
		info->opFunc(opFreeRaster, &vuRaster[i], 0, 0, 0, 0);
}

PLUGIN_API int VISUALDLL_ENTRY_POINT(4)(PluginInfo *pluginInfo, QCDModInfo *modInfo, int fullinit)
{
	modInfo->moduleString = "VU Meters";
	if (fullinit && pluginInfo) {
		info = pluginInfo;
		buffer = info->buffer;

		for (int i = 0; i < 2; ++i)
			if (!info->opFunc(opMakeRaster, &vuRaster[i], 0, 0, vuXSize, vuYSize))
				return 0;

		info->triggerMode = noTrigger;
		info->triggerForm = 0;
		info->resonatorMode = noResonators;
		info->resonatorForm = 0;
		info->vuMeterMode = stereoVUMeter;
		info->ppMeterMode = noPPMeter;

		info->event = 0;
		info->render = Render;
		info->idle = 0;
		info->wrap = Wrap;
		info->about = 0;
		info->configure = 0;

		InitMul();
	}
	return !0;
}

// end of Plugin5.cpp
//
